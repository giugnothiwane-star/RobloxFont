package com.rfc.fontchanger.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rfc.fontchanger.data.PreviewScene
import com.rfc.fontchanger.data.UserPreferences
import com.rfc.fontchanger.ui.theme.RfcColors
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewCard(
    activeName: String?,
    family: FontFamily?,
    originalFamily: FontFamily?,
    originalName: String?,
    text: String,
    sizeSp: Float,
    scene: PreviewScene,
    compare: Boolean,
    onTextChange: (String) -> Unit,
    onSizeChange: (Float) -> Unit,
    onSizeChangeFinished: () -> Unit,
    onSceneChange: (PreviewScene) -> Unit,
    onCompareChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    // Sans police active, l'aperçu principal montre la police d'origine de Roblox si elle a été extraite.
    val primaryFamily = family ?: originalFamily ?: FontFamily.Default
    val primaryLabel = when {
        activeName != null -> activeName
        originalName != null -> "Origine Roblox · $originalName"
        else -> "Police système (aucune sélection)"
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column {
                Text("Aperçu instantané", style = MaterialTheme.typography.titleMedium)
                Text(
                    primaryLabel,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PreviewScene.entries.forEach { s ->
                    FilterChip(
                        selected = s == scene,
                        onClick = { onSceneChange(s) },
                        label = { Text(s.label) },
                    )
                }
            }

            AnimatedContent(
                targetState = scene,
                transitionSpec = {
                    (fadeIn(tween(220)) + slideInHorizontally(tween(220)) { it / 10 }) togetherWith fadeOut(tween(140))
                },
                label = "scene",
            ) { s -> SceneRenderer(s, primaryFamily, text, sizeSp) }

            AnimatedVisibility(
                visible = compare && family != null && originalFamily != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "Origine Roblox${originalName?.let { " · $it" } ?: ""}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    SceneRenderer(scene, originalFamily ?: FontFamily.Default, text, sizeSp)
                }
            }

            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Texte de test") },
                supportingText = { Text("${text.length}/${UserPreferences.MAX_PREVIEW_LENGTH}") },
                maxLines = 3,
            )

            Column {
                Text(
                    "Taille : ${sizeSp.roundToInt()} sp",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Slider(
                    value = sizeSp,
                    onValueChange = onSizeChange,
                    onValueChangeFinished = onSizeChangeFinished,
                    valueRange = UserPreferences.SIZE_RANGE,
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Comparer avec l'origine", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        if (originalFamily != null) "Police extraite de votre installation Roblox"
                        else "Indisponible : police d'origine non trouvée",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = compare, onCheckedChange = onCompareChange, enabled = originalFamily != null)
            }
        }
    }
}

@Composable
private fun SceneRenderer(scene: PreviewScene, family: FontFamily, text: String, sizeSp: Float) {
    val sample = text.ifBlank { " " }
    when (scene) {
        PreviewScene.CHAT -> ChatScene(family, sample, sizeSp)
        PreviewScene.MENU -> MenuScene(family, sizeSp)
        PreviewScene.NAMETAG -> NametagScene(family, sample, sizeSp)
    }
}

@Composable
private fun ChatScene(family: FontFamily, text: String, sizeSp: Float) {
    val lines = listOf(
        Triple("Builderman", Color(0xFF63B3FF), "salut tout le monde"),
        Triple("Toi", Color(0xFFFFB347), text),
        Triple("xX_Pro_Xx", Color(0xFF7CFC9A), "gg"),
    )
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xB3000000))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        lines.forEach { (name, color, msg) ->
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = color, fontWeight = FontWeight.Bold)) { append("$name : ") }
                    append(msg)
                },
                fontFamily = family,
                fontSize = sizeSp.sp,
                color = Color.White,
            )
        }
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0x33FFFFFF))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Text(
                "Appuyez ici pour discuter",
                fontFamily = family,
                fontSize = (sizeSp * 0.8f).sp,
                color = Color(0xB3FFFFFF),
            )
        }
    }
}

@Composable
private fun MenuScene(family: FontFamily, sizeSp: Float) {
    val buttonSize = sizeSp.coerceAtMost(28f)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF191B20))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("Accueil", fontFamily = family, fontSize = (buttonSize * 1.3f).sp, fontWeight = FontWeight.Bold, color = Color.White)
        listOf("Jouer", "Avatar", "Amis", "Paramètres").forEachIndexed { i, label ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (i == 0) Color(0xFF335FFF) else Color(0xFF2B2F38))
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, fontFamily = family, fontSize = buttonSize.sp, color = Color.White, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun NametagScene(family: FontFamily, text: String, sizeSp: Float) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(190.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF6FB7FF), Color(0xFFBFE3FF), Color(0xFF5DBB63)))),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text.take(24),
                fontFamily = family,
                fontSize = sizeSp.sp,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = TextStyle(shadow = Shadow(Color(0xCC000000), Offset(2f, 2f), blurRadius = 3f)),
            )
            Text(
                "@toi_officiel",
                fontFamily = family,
                fontSize = (sizeSp * 0.65f).sp,
                color = Color(0xE6FFFFFF),
                style = TextStyle(shadow = Shadow(Color(0xCC000000), Offset(1f, 1f), blurRadius = 2f)),
            )
            Spacer(Modifier.height(8.dp))
            // Avatar stylisé (tête + torse) pour donner l'échelle du pseudo au-dessus d'un personnage.
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(RfcColors.Warning))
            Spacer(Modifier.height(3.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                Box(Modifier.width(12.dp).height(40.dp).clip(CircleShape).background(RfcColors.Warning))
                Box(Modifier.width(40.dp).height(44.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1E88E5)))
                Box(Modifier.width(12.dp).height(40.dp).clip(CircleShape).background(RfcColors.Warning))
            }
        }
    }
}
