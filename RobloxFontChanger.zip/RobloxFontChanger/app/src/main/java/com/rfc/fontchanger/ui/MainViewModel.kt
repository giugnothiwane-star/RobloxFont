package com.rfc.fontchanger.ui

import android.app.Application
import android.graphics.Typeface
import android.net.Uri
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rfc.fontchanger.RobloxFontApp
import com.rfc.fontchanger.data.FontEntry
import com.rfc.fontchanger.data.PreviewScene
import com.rfc.fontchanger.data.UserPreferences
import com.rfc.fontchanger.data.toAppError
import com.rfc.fontchanger.system.CompatibilityReport
import com.rfc.fontchanger.system.DeviceInfo
import com.rfc.fontchanger.system.RobloxBundledFont
import com.rfc.fontchanger.system.RobloxInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Immutable
data class MainUiState(
    val fonts: List<FontEntry> = emptyList(),
    val activeFont: FontEntry? = null,
    val previewText: String = UserPreferences.DEFAULT_PREVIEW_TEXT,
    val previewSizeSp: Float = UserPreferences.DEFAULT_PREVIEW_SIZE,
    val compareWithOriginal: Boolean = true,
    val scene: PreviewScene = PreviewScene.CHAT,
    val device: DeviceInfo? = null,
    val roblox: RobloxInfo? = null,
    val originalFont: RobloxBundledFont? = null,
    val originalTypeface: Typeface? = null,
    val isImporting: Boolean = false,
    val isAnalyzing: Boolean = false,
    val report: CompatibilityReport? = null,
    val showReport: Boolean = false,
    val showRestoreDialog: Boolean = false,
    val pendingDelete: FontEntry? = null,
    val libraryLoaded: Boolean = false,
)

/** État volatile, non persisté. */
private data class TransientState(
    val previewTextOverride: String? = null,
    val previewSizeOverride: Float? = null,
    val device: DeviceInfo? = null,
    val roblox: RobloxInfo? = null,
    val originalFont: RobloxBundledFont? = null,
    val originalTypeface: Typeface? = null,
    val isImporting: Boolean = false,
    val isAnalyzing: Boolean = false,
    val report: CompatibilityReport? = null,
    val showReport: Boolean = false,
    val showRestoreDialog: Boolean = false,
    val pendingDeleteId: String? = null,
    val libraryLoaded: Boolean = false,
)

@OptIn(FlowPreview::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as RobloxFontApp).container
    private val fontRepo = container.fontRepository
    private val prefsRepo = container.preferencesRepository
    private val inspector = container.environmentInspector
    private val scanner = container.robloxFontScanner
    private val analyzer = container.compatibilityAnalyzer

    private val transient = MutableStateFlow(TransientState())
    private val previewTextWrites = MutableSharedFlow<String>(extraBufferCapacity = 1)

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    val state: StateFlow<MainUiState> = combine(fontRepo.fonts, prefsRepo.preferences, transient) { fonts, prefs, t ->
        MainUiState(
            fonts = fonts,
            activeFont = fonts.firstOrNull { it.id == prefs.activeFontId },
            previewText = t.previewTextOverride ?: prefs.previewText,
            previewSizeSp = t.previewSizeOverride ?: prefs.previewSizeSp,
            compareWithOriginal = prefs.compareWithOriginal,
            scene = prefs.scene,
            device = t.device,
            roblox = t.roblox,
            originalFont = t.originalFont,
            originalTypeface = t.originalTypeface,
            isImporting = t.isImporting,
            isAnalyzing = t.isAnalyzing,
            report = t.report,
            showReport = t.showReport,
            showRestoreDialog = t.showRestoreDialog,
            pendingDelete = t.pendingDeleteId?.let { id -> fonts.firstOrNull { it.id == id } },
            libraryLoaded = t.libraryLoaded,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MainUiState())

    init {
        viewModelScope.launch {
            runCatching { fontRepo.load() }.onFailure { emitError(it) }
            transient.update { it.copy(libraryLoaded = true) }
        }
        viewModelScope.launch {
            // Écriture différée : évite un aller-retour DataStore par frappe clavier.
            previewTextWrites.debounce(400).collect { prefsRepo.setPreviewText(it) }
        }
        refreshEnvironment()
    }

    fun refreshEnvironment() {
        viewModelScope.launch {
            val (device, roblox) = withContext(Dispatchers.IO) { inspector.deviceInfo() to inspector.robloxInfo() }
            transient.update { it.copy(device = device, roblox = roblox) }
            if (roblox != null) loadOriginalFont(roblox)
        }
    }

    private suspend fun loadOriginalFont(roblox: RobloxInfo) {
        try {
            val result = withContext(Dispatchers.IO) {
                val scan = scanner.scan(roblox)
                val pick = scanner.pickDefault(scan.fonts) ?: return@withContext null
                val file = scanner.extract(pick)
                pick to Typeface.Builder(file).build()
            }
            transient.update { it.copy(originalFont = result?.first, originalTypeface = result?.second) }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Comparaison facultative : l'échec ne mérite pas d'interrompre l'utilisateur.
            transient.update { it.copy(originalFont = null, originalTypeface = null) }
        }
    }

    fun importFont(uri: Uri) {
        if (transient.value.isImporting) return
        transient.update { it.copy(isImporting = true) }
        viewModelScope.launch {
            try {
                val entry = fontRepo.import(uri)
                prefsRepo.setActiveFont(entry.id)
                _messages.emit("« ${entry.displayName} » importée et sélectionnée.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emitError(e)
            } finally {
                transient.update { it.copy(isImporting = false) }
            }
        }
    }

    fun selectFont(entry: FontEntry) {
        viewModelScope.launch { prefsRepo.setActiveFont(entry.id) }
    }

    fun requestDelete(entry: FontEntry) = transient.update { it.copy(pendingDeleteId = entry.id) }

    fun cancelDelete() = transient.update { it.copy(pendingDeleteId = null) }

    fun confirmDelete() {
        val id = transient.value.pendingDeleteId ?: return
        transient.update { it.copy(pendingDeleteId = null) }
        viewModelScope.launch {
            try {
                val name = state.value.fonts.firstOrNull { it.id == id }?.displayName
                if (state.value.activeFont?.id == id) prefsRepo.setActiveFont(null)
                fontRepo.delete(id)
                _messages.emit("« ${name ?: "Police"} » supprimée.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emitError(e)
            }
        }
    }

    fun export(entry: FontEntry, target: Uri) {
        viewModelScope.launch {
            try {
                fontRepo.exportTo(entry, target)
                _messages.emit("« ${entry.displayName} » exportée.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emitError(e)
            }
        }
    }

    fun shareUriFor(entry: FontEntry): Uri? = try {
        fontRepo.shareUri(entry)
    } catch (e: Exception) {
        emitError(e)
        null
    }

    fun findFont(id: String): FontEntry? = state.value.fonts.firstOrNull { it.id == id }

    suspend fun typefaceFor(entry: FontEntry): Typeface? = fontRepo.typefaceFor(entry)

    fun onPreviewTextChange(text: String) {
        val clipped = text.take(UserPreferences.MAX_PREVIEW_LENGTH)
        transient.update { it.copy(previewTextOverride = clipped) }
        previewTextWrites.tryEmit(clipped)
    }

    fun onPreviewSizeChange(size: Float) = transient.update { it.copy(previewSizeOverride = size) }

    fun onPreviewSizeChangeFinished() {
        val size = transient.value.previewSizeOverride ?: return
        viewModelScope.launch { prefsRepo.setPreviewSize(size) }
    }

    fun onCompareToggle(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setCompareWithOriginal(enabled) }
    }

    fun onSceneChange(scene: PreviewScene) {
        viewModelScope.launch { prefsRepo.setScene(scene) }
    }

    /** « Appliquer à Roblox » : analyse de faisabilité réelle, jamais de faux succès. */
    fun onApplyRequested() {
        if (state.value.activeFont == null) {
            _messages.tryEmit("Sélectionnez d'abord une police dans la bibliothèque.")
            return
        }
        if (transient.value.isAnalyzing) return
        transient.update { it.copy(isAnalyzing = true) }
        viewModelScope.launch {
            try {
                val report = analyzer.analyze()
                transient.update { it.copy(report = report, showReport = true, roblox = report.roblox) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emitError(e)
            } finally {
                transient.update { it.copy(isAnalyzing = false) }
            }
        }
    }

    fun dismissReport() = transient.update { it.copy(showReport = false) }

    /** Revient à la police d'origine dans l'aperçu et explique l'état réel de Roblox. */
    fun onRestoreRequested() {
        viewModelScope.launch { prefsRepo.setActiveFont(null) }
        transient.update { it.copy(showRestoreDialog = true) }
    }

    fun dismissRestore() = transient.update { it.copy(showRestoreDialog = false) }

    fun notify(message: String) {
        _messages.tryEmit(message)
    }

    private fun emitError(e: Throwable) {
        _messages.tryEmit(e.toAppError().userMessage)
    }
}
