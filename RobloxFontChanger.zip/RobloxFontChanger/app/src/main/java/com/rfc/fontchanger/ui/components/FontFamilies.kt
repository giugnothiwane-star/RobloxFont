package com.rfc.fontchanger.ui.components

import android.graphics.Typeface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily
import com.rfc.fontchanger.data.FontEntry

/** Charge la police hors du thread UI (Typeface lit le fichier) et la convertit pour Compose. */
@Composable
fun rememberFontFamily(entry: FontEntry?, loader: suspend (FontEntry) -> Typeface?): FontFamily? {
    val family by produceState<FontFamily?>(initialValue = null, key1 = entry?.id) {
        value = entry?.let { loader(it) }?.let { FontFamily(it) }
    }
    return family
}

@Composable
fun rememberFontFamily(typeface: Typeface?): FontFamily? =
    remember(typeface) { typeface?.let { FontFamily(it) } }
