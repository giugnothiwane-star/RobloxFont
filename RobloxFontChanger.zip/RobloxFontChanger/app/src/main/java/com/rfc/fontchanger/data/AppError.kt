package com.rfc.fontchanger.data

import java.util.Locale

/**
 * Erreurs métier avec un message destiné directement à l'utilisateur.
 * Chaque cas correspond à une cause identifiable, jamais à un message générique.
 */
sealed class AppError(val userMessage: String, cause: Throwable? = null) : Exception(userMessage, cause) {

    class UnreadableSource(cause: Throwable? = null) :
        AppError("Impossible de lire le fichier sélectionné. Il a peut-être été déplacé ou l'application source a révoqué l'accès.", cause)

    class EmptyFile :
        AppError("Le fichier sélectionné est vide (0 octet).")

    class FileTooLarge(maxBytes: Long) :
        AppError(String.format(Locale.FRANCE, "Fichier trop volumineux. Limite : %d Mo.", maxBytes / (1024 * 1024)))

    class WebFontUnsupported(format: String) :
        AppError("Format $format détecté (police web compressée). Seuls les fichiers .ttf et .otf sont acceptés : convertissez-la d'abord.")

    class CollectionUnsupported :
        AppError("Fichier .ttc (collection de polices) détecté. Extrayez une police individuelle en .ttf ou .otf.")

    class NotAFont :
        AppError("Ce fichier n'est pas une police TrueType/OpenType valide (signature d'en-tête inconnue).")

    class CorruptedFont(detail: String) :
        AppError("Police corrompue ou incomplète : $detail")

    class TypefaceRejected :
        AppError("Le moteur de rendu Android refuse cette police (tables invalides ou non supportées).")

    class AlreadyImported(name: String) :
        AppError("« $name » est déjà dans votre bibliothèque.")

    class StorageFull(cause: Throwable? = null) :
        AppError("Espace de stockage insuffisant pour importer la police.", cause)

    class FontNotFound :
        AppError("Fichier de police introuvable dans la bibliothèque. Il a peut-être été supprimé.")

    class ExportFailed(cause: Throwable? = null) :
        AppError("L'export a échoué : l'emplacement choisi n'accepte pas l'écriture.", cause)

    class RobloxNotInstalled :
        AppError("Roblox n'est pas installé sur cet appareil.")

    class RobloxFontUnavailable(cause: Throwable? = null) :
        AppError("Impossible d'extraire la police d'origine de Roblox pour la comparaison.", cause)

    class Unexpected(cause: Throwable) :
        AppError("Erreur inattendue : ${cause.javaClass.simpleName}${cause.message?.let { " — $it" } ?: ""}", cause)
}

/** Normalise n'importe quelle exception en [AppError] affichable. */
fun Throwable.toAppError(): AppError = this as? AppError ?: AppError.Unexpected(this)
