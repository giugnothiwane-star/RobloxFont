package com.rfc.fontchanger.system

import android.content.Context
import androidx.compose.runtime.Immutable
import com.rfc.fontchanger.data.AppError
import java.io.File
import java.io.IOException
import java.util.zip.ZipException
import java.util.zip.ZipFile

@Immutable
data class RobloxBundledFont(
    val apkName: String,
    val apkPath: String,
    val entryPath: String,
    val sizeBytes: Long,
) {
    val fileName: String get() = entryPath.substringAfterLast('/')
}

@Immutable
data class RobloxFontScan(
    val fonts: List<RobloxBundledFont>,
    val readableApks: Int,
    val unreadableApks: Int,
)

/**
 * Lecture SEULE des APK de Roblox. Les APK installés sont lisibles par toutes les
 * applications (c'est ce qui permet aux extracteurs d'APK de fonctionner) ; ils ne sont
 * en revanche jamais modifiables. Cette classe n'écrit que dans le cache de notre app.
 */
class RobloxFontScanner(context: Context) {

    private val cacheDir = File(context.applicationContext.cacheDir, "roblox_original")

    fun scan(info: RobloxInfo): RobloxFontScan {
        var readable = 0
        var unreadable = 0
        val fonts = ArrayList<RobloxBundledFont>()
        for (path in info.apkPaths) {
            val apk = File(path)
            try {
                ZipFile(apk).use { zip ->
                    readable++
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        if (e.isDirectory) continue
                        val lower = e.name.lowercase()
                        if (lower.endsWith(".ttf") || lower.endsWith(".otf")) {
                            fonts += RobloxBundledFont(apk.name, path, e.name, e.size.coerceAtLeast(0))
                        }
                    }
                }
            } catch (_: IOException) {
                unreadable++
            } catch (_: SecurityException) {
                unreadable++
            }
        }
        return RobloxFontScan(fonts.sortedBy { it.entryPath }, readable, unreadable)
    }

    /** Police la plus probablement utilisée par défaut dans l'interface Roblox actuelle. */
    fun pickDefault(fonts: List<RobloxBundledFont>): RobloxBundledFont? {
        val priorities = listOf(
            Regex("builder\\s*sans.*regular", RegexOption.IGNORE_CASE),
            Regex("buildersans.*(medium|regular)", RegexOption.IGNORE_CASE),
            Regex("gotham.*(book|regular)", RegexOption.IGNORE_CASE),
            Regex("sourcesans.*regular", RegexOption.IGNORE_CASE),
            Regex("regular", RegexOption.IGNORE_CASE),
        )
        for (p in priorities) fonts.firstOrNull { p.containsMatchIn(it.fileName) }?.let { return it }
        return fonts.firstOrNull()
    }

    /** Extrait une police d'origine dans notre cache, pour comparaison visuelle uniquement. */
    fun extract(font: RobloxBundledFont): File {
        if (font.sizeBytes > MAX_EXTRACT_BYTES) throw AppError.RobloxFontUnavailable()
        // Nom assaini : empêche toute traversée de répertoire via un nom d'entrée ZIP piégé.
        val safeName = font.fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "font.ttf" }
        if (!cacheDir.isDirectory && !cacheDir.mkdirs()) throw AppError.StorageFull()
        val out = File(cacheDir, safeName)
        if (out.isFile && out.length() == font.sizeBytes && font.sizeBytes > 0) return out

        val tmp = File(cacheDir, "$safeName.part")
        try {
            ZipFile(File(font.apkPath)).use { zip ->
                val entry = zip.getEntry(font.entryPath) ?: throw AppError.RobloxFontUnavailable()
                zip.getInputStream(entry).use { input ->
                    tmp.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var total = 0L
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            total += read
                            if (total > MAX_EXTRACT_BYTES) throw AppError.RobloxFontUnavailable()
                            output.write(buffer, 0, read)
                        }
                    }
                }
            }
            if (!tmp.renameTo(out)) throw AppError.RobloxFontUnavailable()
            return out
        } catch (e: AppError) {
            throw e
        } catch (e: ZipException) {
            throw AppError.RobloxFontUnavailable(e)
        } catch (e: IOException) {
            throw AppError.RobloxFontUnavailable(e)
        } catch (e: SecurityException) {
            throw AppError.RobloxFontUnavailable(e)
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    private companion object {
        const val MAX_EXTRACT_BYTES = 30L * 1024 * 1024
    }
}
