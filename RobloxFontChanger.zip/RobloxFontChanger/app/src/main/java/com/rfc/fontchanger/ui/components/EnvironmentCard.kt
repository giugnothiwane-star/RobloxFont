package com.rfc.fontchanger.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rfc.fontchanger.system.DeviceInfo
import com.rfc.fontchanger.system.RobloxInfo
import com.rfc.fontchanger.ui.theme.RfcColors

@Composable
fun EnvironmentCard(
    device: DeviceInfo?,
    roblox: RobloxInfo?,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Environnement détecté", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, contentDescription = "Actualiser la détection") }
            }
            Column(Modifier.padding(end = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (device == null) {
                    InfoLine("Appareil", "Détection…")
                } else {
                    InfoLine("Appareil", "${device.manufacturer} ${device.model}")
                    InfoLine("Système", device.androidLabel)
                    device.oneUiVersion?.let { InfoLine("One UI", it) }
                    InfoLine("Correctif sécurité", device.securityPatch)
                }
                if (roblox == null) {
                    InfoLine("Roblox", if (device == null) "Détection…" else "Non installé", RfcColors.Danger.takeIf { device != null })
                } else {
                    InfoLine("Roblox", roblox.versionName)
                    InfoLine(
                        "Source",
                        roblox.installer.label,
                        if (roblox.installer.isOfficial) RfcColors.Success else RfcColors.Warning,
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String, valueColor: Color? = null) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = valueColor ?: MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1.4f),
        )
    }
}
