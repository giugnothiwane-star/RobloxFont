package com.rfc.fontchanger.system

import android.os.Build
import android.os.Environment
import androidx.compose.runtime.Immutable
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class CheckStatus { OK, INFO, WARNING, BLOCKED }

@Immutable
data class CheckResult(val title: String, val status: CheckStatus, val detail: String)

@Immutable
data class CompatibilityReport(
    val generatedAt: Long,
    val device: DeviceInfo,
    val roblox: RobloxInfo?,
    val checks: List<CheckResult>,
    val bundledFonts: List<RobloxBundledFont>,
    /** Toujours false sans root : l'application n'implémente volontairement aucune écriture dans Roblox. */
    val canApply: Boolean,
    val verdict: String,
    val alternatives: List<String>,
)

/**
 * Exécute des vérifications RÉELLES sur l'appareil (accès fichiers, source d'installation,
 * contenu des APK) puis produit un verdict argumenté. Aucune écriture n'est tentée.
 */
class CompatibilityAnalyzer(
    private val inspector: EnvironmentInspector,
    private val scanner: RobloxFontScanner,
    private val io: CoroutineDispatcher = Dispatchers.IO,
) {

    suspend fun analyze(): CompatibilityReport = withContext(io) {
        val device = inspector.deviceInfo()
        val roblox = inspector.robloxInfo()
        val checks = ArrayList<CheckResult>()

        if (roblox == null) {
            checks += CheckResult(
                "Roblox installé", CheckStatus.BLOCKED,
                "Aucun paquet Roblox détecté (${EnvironmentInspector.ROBLOX_PACKAGES.joinToString()})."
            )
            return@withContext CompatibilityReport(
                generatedAt = System.currentTimeMillis(),
                device = device,
                roblox = null,
                checks = checks,
                bundledFonts = emptyList(),
                canApply = false,
                verdict = "Roblox n'est pas installé : rien à analyser.",
                alternatives = listOf("Installez Roblox depuis Google Play ou le Galaxy Store, puis relancez l'analyse."),
            )
        }

        checks += CheckResult(
            "Roblox installé", CheckStatus.OK,
            "${roblox.packageName} — version ${roblox.versionName} (code ${roblox.versionCode})."
        )

        checks += if (roblox.installer.isOfficial) {
            CheckResult("Source d'installation", CheckStatus.OK, "${roblox.installer.label} : APK officiel signé par Roblox.")
        } else {
            CheckResult(
                "Source d'installation", CheckStatus.WARNING,
                "${roblox.installer.label}${roblox.installerPackage?.let { " ($it)" } ?: ""}. " +
                    "Un APK hors store officiel peut être modifié et compromettre votre compte."
            )
        }

        val scan = scanner.scan(roblox)
        checks += when {
            scan.readableApks == 0 -> CheckResult(
                "Polices embarquées", CheckStatus.WARNING,
                "Les APK de Roblox n'ont pas pu être lus (${scan.unreadableApks} fichier(s))."
            )
            scan.fonts.isEmpty() -> CheckResult(
                "Polices embarquées", CheckStatus.INFO,
                "Aucun fichier .ttf/.otf trouvé dans ${scan.readableApks} APK : les polices sont probablement compressées dans un format interne."
            )
            else -> {
                val apks = scan.fonts.map { it.apkName }.distinct().joinToString()
                CheckResult(
                    "Polices embarquées", CheckStatus.INFO,
                    "${scan.fonts.size} police(s) trouvée(s) DANS l'APK signé ($apks). Elles font partie du paquet installé, pas de fichiers externes."
                )
            }
        }

        checks += checkApkWritable(roblox)
        checks += checkPrivateData(roblox)
        checks += checkExternalAppData(roblox, device.sdkInt)
        checks += CheckResult(
            "Mécanisme de surcharge officiel", CheckStatus.BLOCKED,
            "Sur Windows, Bloxstrap remplace les fichiers du dossier « content/fonts » de l'installation, " +
                "qui est un dossier ordinaire modifiable. Sur Android, ce contenu est empaqueté dans l'APK et " +
                "Roblox n'expose aucun dossier, réglage ou API permettant de charger une police externe."
        )

        CompatibilityReport(
            generatedAt = System.currentTimeMillis(),
            device = device,
            roblox = roblox,
            checks = checks,
            bundledFonts = scan.fonts,
            canApply = false,
            verdict = "Remplacement impossible sans root sur ${device.androidLabel}. " +
                "Les polices de Roblox sont dans un APK signé en lecture seule et dans un bac à sable " +
                "inaccessible aux autres applications. Aucune modification n'a été tentée.",
            alternatives = listOf(
                "Prévisualiser vos polices dans des maquettes de chat, de menus et de pseudos, côte à côte avec la police d'origine extraite de Roblox.",
                "Exporter ou partager une police vers un PC : Bloxstrap (Windows) permet d'appliquer une police personnalisée au client Roblox.",
                "Conserver une bibliothèque organisée de vos polices, prête à être réutilisée.",
            ),
        )
    }

    private fun checkApkWritable(roblox: RobloxInfo): CheckResult {
        val apk = roblox.sourceDir?.let(::File)
        val writable = apk != null && (apk.canWrite() || apk.parentFile?.canWrite() == true)
        return if (writable) {
            // Cas anormal (appareil rooté ou permissions altérées) : on le signale sans en profiter.
            CheckResult(
                "APK de Roblox", CheckStatus.WARNING,
                "Le dossier de l'APK semble modifiable : configuration système anormale. " +
                    "Toute modification casserait la signature et Android refuserait les mises à jour."
            )
        } else {
            CheckResult(
                "APK de Roblox", CheckStatus.BLOCKED,
                "Lecture seule (${apk?.parent ?: "/data/app"}). L'APK est signé : modifier une police " +
                    "invaliderait la signature, Android refuserait l'installation et Roblox serait considéré comme altéré."
            )
        }
    }

    private fun checkPrivateData(roblox: RobloxInfo): CheckResult {
        val dir = roblox.dataDir?.let(::File)
        val accessible = dir != null && (dir.canRead() || dir.canWrite())
        return CheckResult(
            "Données internes de Roblox",
            if (accessible) CheckStatus.WARNING else CheckStatus.BLOCKED,
            if (accessible) {
                "Accès inattendu au bac à sable de Roblox : configuration système anormale."
            } else {
                "Inaccessible (${dir?.path ?: "/data/user/0/${roblox.packageName}"}) : chaque application Android " +
                    "possède son propre identifiant Linux et ses fichiers privés sont isolés par le noyau et SELinux."
            }
        )
    }

    @Suppress("DEPRECATION")
    private fun checkExternalAppData(roblox: RobloxInfo, sdkInt: Int): CheckResult {
        val dir = File(Environment.getExternalStorageDirectory(), "Android/data/${roblox.packageName}")
        val writable = dir.canWrite()
        if (writable) {
            return CheckResult(
                "Android/data de Roblox", CheckStatus.INFO,
                "Dossier accessible, mais Roblox n'y lit aucune police : y écrire n'aurait aucun effet."
            )
        }
        val reason = when {
            sdkInt >= Build.VERSION_CODES.TIRAMISU ->
                "Bloqué : depuis Android 13, le sélecteur de fichiers système refuse même de proposer Android/data, " +
                    "et le stockage limité (Android 11+) interdit tout accès direct."
            sdkInt >= Build.VERSION_CODES.R ->
                "Bloqué par le stockage limité (scoped storage) d'Android 11+."
            else ->
                "Non accessible en écriture pour cette application."
        }
        return CheckResult("Android/data de Roblox", CheckStatus.BLOCKED, reason)
    }
}
