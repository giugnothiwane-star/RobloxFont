package com.rfc.fontchanger.data

import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.nio.charset.Charset

enum class FontFormat(val extension: String, val label: String, val mimeType: String) {
    TRUETYPE("ttf", "TTF", "font/ttf"),
    OPENTYPE_CFF("otf", "OTF", "font/otf");

    companion object {
        fun fromExtension(ext: String): FontFormat? = entries.firstOrNull { it.extension.equals(ext, ignoreCase = true) }
    }
}

data class FontMetadata(
    val format: FontFormat,
    val family: String?,
    val subfamily: String?,
    val fullName: String?,
    val glyphCount: Int?,
    val weightClass: Int?,
    val isVariable: Boolean,
)

/**
 * Parseur SFNT minimal (TrueType / OpenType-CFF).
 * Valide la structure avant de confier le fichier à Typeface : certaines polices
 * malformées provoquent sinon un rendu silencieusement remplacé par la police système.
 */
object FontParser {

    private const val TAG_TRUETYPE = 0x00010000
    private const val TAG_OTTO = 0x4F54544F // 'OTTO'
    private const val TAG_TRUE = 0x74727565 // 'true' (anciennes polices Apple)
    private const val TAG_TTCF = 0x74746366 // 'ttcf'
    private const val TAG_WOFF = 0x774F4646 // 'wOFF'
    private const val TAG_WOF2 = 0x774F4632 // 'wOF2'

    private const val MAX_TABLES = 512
    private const val MAX_NAME_LENGTH = 128

    private data class TableRecord(val offset: Int, val length: Int)

    fun parse(file: File): FontMetadata {
        try {
            RandomAccessFile(file, "r").use { raf ->
                val size = raf.length()
                if (size < 12) throw AppError.CorruptedFont("en-tête tronqué")
                if (size > Int.MAX_VALUE) throw AppError.CorruptedFont("taille hors limites")
                // Mappage mémoire : lecture aléatoire des tables sans tout charger en heap.
                val buffer = raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, size).order(ByteOrder.BIG_ENDIAN)
                return parseBuffer(buffer, size.toInt())
            }
        } catch (e: AppError) {
            throw e
        } catch (e: IOException) {
            throw AppError.UnreadableSource(e)
        } catch (e: IndexOutOfBoundsException) {
            throw AppError.CorruptedFont("lecture hors limites")
        } catch (e: IllegalArgumentException) {
            throw AppError.CorruptedFont("structure invalide")
        }
    }

    private fun parseBuffer(buf: ByteBuffer, size: Int): FontMetadata {
        val format = when (buf.getInt(0)) {
            TAG_TRUETYPE, TAG_TRUE -> FontFormat.TRUETYPE
            TAG_OTTO -> FontFormat.OPENTYPE_CFF
            TAG_TTCF -> throw AppError.CollectionUnsupported()
            TAG_WOFF -> throw AppError.WebFontUnsupported("WOFF")
            TAG_WOF2 -> throw AppError.WebFontUnsupported("WOFF2")
            else -> throw AppError.NotAFont()
        }

        val numTables = buf.u16(4)
        if (numTables !in 1..MAX_TABLES) throw AppError.CorruptedFont("nombre de tables invalide ($numTables)")
        if (12L + numTables * 16L > size) throw AppError.CorruptedFont("répertoire de tables tronqué")

        val tables = HashMap<String, TableRecord>(numTables * 2)
        for (i in 0 until numTables) {
            val rec = 12 + i * 16
            val tag = buf.tag(rec)
            val offset = buf.u32(rec + 8)
            val length = buf.u32(rec + 12)
            if (offset + length > size) throw AppError.CorruptedFont("table « ${tag.trim()} » hors du fichier")
            tables[tag] = TableRecord(offset.toInt(), length.toInt())
        }

        listOf("cmap", "head", "name").forEach { required ->
            if (required !in tables) throw AppError.CorruptedFont("table obligatoire « $required » absente")
        }
        when (format) {
            FontFormat.TRUETYPE -> if ("glyf" !in tables || "loca" !in tables) {
                throw AppError.CorruptedFont("contours TrueType (glyf/loca) absents")
            }
            FontFormat.OPENTYPE_CFF -> if ("CFF " !in tables && "CFF2" !in tables) {
                throw AppError.CorruptedFont("contours CFF absents")
            }
        }

        val glyphCount = tables["maxp"]?.takeIf { it.length >= 6 }?.let { buf.u16(it.offset + 4) }
        val weightClass = tables["OS/2"]?.takeIf { it.length >= 6 }?.let { buf.u16(it.offset + 4) }
        val names = tables.getValue("name").let { parseNameTable(buf, it) }

        return FontMetadata(
            format = format,
            family = names[16] ?: names[1],
            subfamily = names[17] ?: names[2],
            fullName = names[4],
            glyphCount = glyphCount,
            weightClass = weightClass,
            isVariable = "fvar" in tables,
        )
    }

    /** Retourne nameID -> chaîne, en préférant Windows/anglais US, puis Unicode, puis Mac. */
    private fun parseNameTable(buf: ByteBuffer, table: TableRecord): Map<Int, String> {
        if (table.length < 6) return emptyMap()
        val base = table.offset
        val count = buf.u16(base + 2)
        val stringStorage = base + buf.u16(base + 4)
        val tableEnd = base + table.length
        if (base + 6 + count * 12 > tableEnd) return emptyMap()

        val wanted = setOf(1, 2, 4, 16, 17)
        val best = HashMap<Int, Pair<Int, String>>()
        for (i in 0 until count) {
            val rec = base + 6 + i * 12
            val nameId = buf.u16(rec + 6)
            if (nameId !in wanted) continue
            val platformId = buf.u16(rec)
            val encodingId = buf.u16(rec + 2)
            val languageId = buf.u16(rec + 4)
            val length = buf.u16(rec + 8)
            val start = stringStorage + buf.u16(rec + 10)
            if (length == 0 || start + length > tableEnd) continue

            val (charset, score) = when {
                platformId == 3 && languageId == 0x0409 -> Charsets.UTF_16BE to 3
                platformId == 3 -> Charsets.UTF_16BE to 2
                platformId == 0 -> Charsets.UTF_16BE to 1
                platformId == 1 && encodingId == 0 -> Charsets.ISO_8859_1 to 0
                else -> continue
            }
            if ((best[nameId]?.first ?: -1) >= score) continue
            val decoded = buf.decode(start, length, charset).sanitize() ?: continue
            best[nameId] = score to decoded
        }
        return best.mapValues { it.value.second }
    }

    private fun ByteBuffer.u16(pos: Int): Int = getShort(pos).toInt() and 0xFFFF
    private fun ByteBuffer.u32(pos: Int): Long = getInt(pos).toLong() and 0xFFFFFFFFL
    private fun ByteBuffer.tag(pos: Int): String = buildString(4) { repeat(4) { append((get(pos + it).toInt() and 0xFF).toChar()) } }

    private fun ByteBuffer.decode(pos: Int, length: Int, charset: Charset): String {
        val bytes = ByteArray(length)
        val dup = duplicate()
        dup.position(pos)
        dup.get(bytes)
        return String(bytes, charset)
    }

    private fun String.sanitize(): String? =
        filter { !it.isISOControl() }.trim().take(MAX_NAME_LENGTH).ifEmpty { null }
}
