package com.rfc.fontchanger.data

import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

enum class FontFormat(val extension: String, val label: String, val mimeType: String) {
    TRUETYPE("ttf", "TTF", "font/ttf"),
    OPENTYPE_CFF("otf", "OTF", "font/otf");

    companion object {
        fun fromExtension(ext: String): FontFormat? = entries.firstOrNull { it.extension.equals(ext, ignoreCase = true) }
    }
}

data class FontMetadata(
    val format: FontFormat,
    val family: String?,
    val subfamily: String?,
    val fullName: String?,
    val glyphCount: Int?,
    val weightClass: Int?,
    val isVariable: Boolean,
)

/**
 * Identification de format + extraction de métadonnées, en mode « meilleur effort ».
 *
 * Seule la signature d'en-tête est bloquante (WOFF, TTC, fichier non-police). Tout le reste
 * (répertoire de tables, noms, compteurs) est lu si possible et ignoré en cas d'anomalie :
 * de nombreuses polices générées par des outils en ligne (FontStruct, polices pixel) ont des
 * tables mal déclarées tout en étant parfaitement rendues par Android. Le verdict final de
 * validité appartient à Typeface.Builder, appelé par le dépôt après ce parseur.
 */
object FontParser {

    private const val TAG_TRUETYPE = 0x00010000
    private const val TAG_OTTO = 0x4F54544F // 'OTTO'
    private const val TAG_TRUE = 0x74727565 // 'true' (anciennes polices Apple)
    private const val TAG_TTCF = 0x74746366 // 'ttcf'
    private const val TAG_WOFF = 0x774F4646 // 'wOFF'
    private const val TAG_WOF2 = 0x774F4632 // 'wOF2'

    private const val MAX_TABLES = 512
    private const val MAX_NAME_LENGTH = 128
    private const val MAX_FILE_BYTES = 30L * 1024 * 1024

    private data class TableRecord(val offset: Int, val length: Int)

    fun parse(file: File): FontMetadata {
        val bytes = try {
            val length = file.length()
            if (length > MAX_FILE_BYTES) throw AppError.FileTooLarge(MAX_FILE_BYTES)
            // Lecture en tas plutôt que mmap : comportement identique sur tous les systèmes de fichiers OEM.
            file.readBytes()
        } catch (e: IOException) {
            throw AppError.UnreadableSource(e)
        }
        if (bytes.size < 12) throw AppError.CorruptedFont("fichier trop court pour être une police (${bytes.size} octets)")

        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
        val format = when (buf.getInt(0)) {
            TAG_TRUETYPE, TAG_TRUE -> FontFormat.TRUETYPE
            TAG_OTTO -> FontFormat.OPENTYPE_CFF
            TAG_TTCF -> throw AppError.CollectionUnsupported()
            TAG_WOFF -> throw AppError.WebFontUnsupported("WOFF")
            TAG_WOF2 -> throw AppError.WebFontUnsupported("WOFF2")
            else -> throw AppError.NotAFont()
        }

        return try {
            extractMetadata(buf, bytes.size, format)
        } catch (_: RuntimeException) {
            // Structure atypique : on garde le format, les métadonnées resteront vides.
            FontMetadata(format, null, null, null, null, null, false)
        }
    }

    private fun extractMetadata(buf: ByteBuffer, size: Int, format: FontFormat): FontMetadata {
        val tables = readTableDirectory(buf, size)

        val glyphCount = tables["maxp"]?.let { safeU16(buf, it, 4) }
        val weightClass = tables["OS/2"]?.let { safeU16(buf, it, 4) }?.takeIf { it in 1..1000 }
        val names = tables["name"]?.let { table ->
            try {
                parseNameTable(buf, table, size)
            } catch (_: RuntimeException) {
                emptyMap()
            }
        }.orEmpty()

        return FontMetadata(
            format = format,
            family = names[16] ?: names[1],
            subfamily = names[17] ?: names[2],
            fullName = names[4],
            glyphCount = glyphCount,
            weightClass = weightClass,
            isVariable = "fvar" in tables,
        )
    }

    /** Lit le répertoire de tables en ignorant les entrées incohérentes au lieu d'échouer. */
    private fun readTableDirectory(buf: ByteBuffer, size: Int): Map<String, TableRecord> {
        val numTables = buf.u16(4)
        if (numTables !in 1..MAX_TABLES) return emptyMap()
        val readable = minOf(numTables, (size - 12) / 16)

        val tables = HashMap<String, TableRecord>(readable * 2)
        for (i in 0 until readable) {
            val rec = 12 + i * 16
            val tag = buf.tag(rec)
            val offset = buf.u32(rec + 8)
            val declaredLength = buf.u32(rec + 12)
            if (offset >= size) continue
            val length = minOf(declaredLength, size.toLong() - offset)
            if (length <= 0) continue
            tables[tag] = TableRecord(offset.toInt(), length.toInt())
        }
        return tables
    }

    private fun safeU16(buf: ByteBuffer, table: TableRecord, relative: Int): Int? {
        val pos = table.offset + relative
        return if (relative + 2 <= table.length && pos >= 0 && pos + 2 <= buf.capacity()) buf.u16(pos) else null
    }

    /** Retourne nameID -> chaîne, en préférant Windows/anglais US, puis Unicode, puis Mac. */
    private fun parseNameTable(buf: ByteBuffer, table: TableRecord, size: Int): Map<Int, String> {
        if (table.length < 6) return emptyMap()
        val base = table.offset
        val tableEnd = minOf(base + table.length, size)
        val count = buf.u16(base + 2)
        val stringStorage = base + buf.u16(base + 4)
        val maxRecords = (tableEnd - base - 6) / 12

        val wanted = setOf(1, 2, 4, 16, 17)
        val best = HashMap<Int, Pair<Int, String>>()
        for (i in 0 until minOf(count, maxRecords)) {
            val rec = base + 6 + i * 12
            val nameId = buf.u16(rec + 6)
            if (nameId !in wanted) continue
            val platformId = buf.u16(rec)
            val encodingId = buf.u16(rec + 2)
            val languageId = buf.u16(rec + 4)
            val length = buf.u16(rec + 8)
            val start = stringStorage + buf.u16(rec + 10)
            if (length == 0 || start < 0 || start + length > tableEnd) continue

            val (charset, score) = when {
                platformId == 3 && languageId == 0x0409 -> Charsets.UTF_16BE to 3
                platformId == 3 -> Charsets.UTF_16BE to 2
                platformId == 0 -> Charsets.UTF_16BE to 1
                platformId == 1 && encodingId == 0 -> Charsets.ISO_8859_1 to 0
                else -> continue
            }
            if ((best[nameId]?.first ?: -1) >= score) continue
            val decoded = String(buf.array(), start, length, charset).sanitize() ?: continue
            best[nameId] = score to decoded
        }
        return best.mapValues { it.value.second }
    }

    private fun ByteBuffer.u16(pos: Int): Int = getShort(pos).toInt() and 0xFFFF
    private fun ByteBuffer.u32(pos: Int): Long = getInt(pos).toLong() and 0xFFFFFFFFL
    private fun ByteBuffer.tag(pos: Int): String = buildString(4) { repeat(4) { append((get(pos + it).toInt() and 0xFF).toChar()) } }

    private fun String.sanitize(): String? =
        filter { !it.isISOControl() }.trim().take(MAX_NAME_LENGTH).ifEmpty { null }
}
