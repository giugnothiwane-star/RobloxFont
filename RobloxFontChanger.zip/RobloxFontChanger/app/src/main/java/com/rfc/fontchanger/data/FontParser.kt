package com.rfc.fontchanger.data

import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.nio.charset.Charset

enum class FontFormat(val extension: String, val label: String, val mimeType: String) {
    TRUETYPE("ttf", "TTF", "font/ttf"),
    OPENTYPE_CFF("otf", "OTF", "font/otf");

    companion object {
        fun fromExtension(ext: String): FontFormat? = entries.firstOrNull { it.extension.equals(ext, ignoreCase = true) }
    }
}

data class FontMetadata(
    val format: FontFormat,
    val family: String?,
    val subfamily: String?,
    val fullName: String?,
    val glyphCount: Int?,
    val weightClass: Int?,
    val isVariable: Boolean,
)

/**
 * Parseur SFNT tolérant (TrueType / OpenType-CFF).
 *
 * Rôle : identifier le format, rejeter ce qui n'est certainement pas une police (WOFF, TTC,
 * fichier quelconque) et extraire les métadonnées. Il NE juge PAS la validité fine des tables :
 * beaucoup de polices générées par des outils en ligne (FontStruct, polices pixel) déclarent des
 * longueurs de table inexactes ou omettent des tables optionnelles, alors que le moteur de rendu
 * d'Android les affiche correctement. Le verdict final appartient à Typeface.Builder.
 */
object FontParser {

    private const val TAG_TRUETYPE = 0x00010000
    private const val TAG_OTTO = 0x4F54544F // 'OTTO'
    private const val TAG_TRUE = 0x74727565 // 'true' (anciennes polices Apple)
    private const val TAG_TTCF = 0x74746366 // 'ttcf'
    private const val TAG_WOFF = 0x774F4646 // 'wOFF'
    private const val TAG_WOF2 = 0x774F4632 // 'wOF2'

    private const val MAX_TABLES = 512
    private const val MAX_NAME_LENGTH = 128

    private data class TableRecord(val offset: Int, val length: Int)

    fun parse(file: File): FontMetadata {
        try {
            RandomAccessFile(file, "r").use { raf ->
                val size = raf.length()
                if (size < 12) throw AppError.CorruptedFont("fichier trop court pour être une police (${size} octets)")
                if (size > Int.MAX_VALUE) throw AppError.CorruptedFont("taille hors limites")
                // Mappage mémoire : lecture aléatoire des tables sans tout charger en heap.
                val buffer = raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, size).order(ByteOrder.BIG_ENDIAN)
                return parseBuffer(buffer, size.toInt())
            }
        } catch (e: AppError) {
            throw e
        } catch (e: IOException) {
            throw AppError.UnreadableSource(e)
        } catch (e: IndexOutOfBoundsException) {
            throw AppError.CorruptedFont("lecture hors limites de l'en-tête")
        } catch (e: IllegalArgumentException) {
            throw AppError.CorruptedFont("structure d'en-tête invalide")
        }
    }

    private fun parseBuffer(buf: ByteBuffer, size: Int): FontMetadata {
        val format = when (buf.getInt(0)) {
            TAG_TRUETYPE, TAG_TRUE -> FontFormat.TRUETYPE
            TAG_OTTO -> FontFormat.OPENTYPE_CFF
            TAG_TTCF -> throw AppError.CollectionUnsupported()
            TAG_WOFF -> throw AppError.WebFontUnsupported("WOFF")
            TAG_WOF2 -> throw AppError.WebFontUnsupported("WOFF2")
            else -> throw AppError.NotAFont()
        }

        // Seules erreurs bloquantes : un répertoire de tables illisible rend le fichier inexploitable.
        val numTables = buf.u16(4)
        if (numTables !in 1..MAX_TABLES) throw AppError.CorruptedFont("nombre de tables invalide ($numTables)")
        if (12L + numTables * 16L > size) throw AppError.CorruptedFont("répertoire de tables tronqué")

        val tables = HashMap<String, TableRecord>(numTables * 2)
        for (i in 0 until numTables) {
            val rec = 12 + i * 16
            val tag = buf.tag(rec)
            val offset = buf.u32(rec + 8)
            val declaredLength = buf.u32(rec + 12)
            // Table qui commence hors du fichier : ignorée. Table qui déborde : tronquée à la fin du fichier.
            if (offset >= size) continue
            val length = minOf(declaredLength, size - offset)
            tables[tag] = TableRecord(offset.toInt(), length.toInt())
        }

        val glyphCount = tables["maxp"]?.takeIf { it.length >= 6 }?.let { buf.u16(it.offset + 4) }
        val weightClass = tables["OS/2"]?.takeIf { it.length >= 6 }?.let { buf.u16(it.offset + 4) }?.takeIf { it in 1..1000 }
        val names = tables["name"]?.let { safeParseNames(buf, it) }.orEmpty()

        return FontMetadata(
            format = format,
            family = names[16] ?: names[1],
            subfamily = names[17] ?: names[2],
            fullName = names[4],
            glyphCount = glyphCount,
            weightClass = weightClass,
            isVariable = "fvar" in tables,
        )
    }

    /** Une table « name » abîmée ne doit jamais faire échouer l'import : on perd juste le nom. */
    private fun safeParseNames(buf: ByteBuffer, table: TableRecord): Map<Int, String> = try {
        parseNameTable(buf, table)
    } catch (_: IndexOutOfBoundsException) {
        emptyMap()
    } catch (_: IllegalArgumentException) {
        emptyMap()
    }

    /** Retourne nameID -> chaîne, en préférant Windows/anglais US, puis Unicode, puis Mac. */
    private fun parseNameTable(buf: ByteBuffer, table: TableRecord): Map<Int, String> {
        if (table.length < 6) return emptyMap()
        val base = table.offset
        val tableEnd = base + table.length
        val count = buf.u16(base + 2)
        val stringStorage = base + buf.u16(base + 4)
        val maxRecords = (table.length - 6) / 12

        val wanted = setOf(1, 2, 4, 16, 17)
        val best = HashMap<Int, Pair<Int, String>>()
        for (i in 0 until minOf(count, maxRecords)) {
            val rec = base + 6 + i * 12
            val nameId = buf.u16(rec + 6)
            if (nameId !in wanted) continue
            val platformId = buf.u16(rec)
            val encodingId = buf.u16(rec + 2)
            val languageId = buf.u16(rec + 4)
            val length = buf.u16(rec + 8)
            val start = stringStorage + buf.u16(rec + 10)
            if (length == 0 || start + length > tableEnd) continue

            val (charset, score) = when {
                platformId == 3 && languageId == 0x0409 -> Charsets.UTF_16BE to 3
                platformId == 3 -> Charsets.UTF_16BE to 2
                platformId == 0 -> Charsets.UTF_16BE to 1
                platformId == 1 && encodingId == 0 -> Charsets.ISO_8859_1 to 0
                else -> continue
            }
            if ((best[nameId]?.first ?: -1) >= score) continue
            val decoded = buf.decode(start, length, charset).sanitize() ?: continue
            best[nameId] = score to decoded
        }
        return best.mapValues { it.value.second }
    }

    private fun ByteBuffer.u16(pos: Int): Int = getShort(pos).toInt() and 0xFFFF
    private fun ByteBuffer.u32(pos: Int): Long = getInt(pos).toLong() and 0xFFFFFFFFL
    private fun ByteBuffer.tag(pos: Int): String = buildString(4) { repeat(4) { append((get(pos + it).toInt() and 0xFF).toChar()) } }

    private fun ByteBuffer.decode(pos: Int, length: Int, charset: Charset): String {
        val bytes = ByteArray(length)
        val dup = duplicate()
        dup.position(pos)
        dup.get(bytes)
        return String(bytes, charset)
    }

    private fun String.sanitize(): String? =
        filter { !it.isISOControl() }.trim().take(MAX_NAME_LENGTH).ifEmpty { null }
}
