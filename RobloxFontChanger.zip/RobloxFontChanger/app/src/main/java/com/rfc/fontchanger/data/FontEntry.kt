package com.rfc.fontchanger.data

import androidx.compose.runtime.Immutable
import kotlinx.serialization.Serializable
import java.util.Locale

@Immutable
@Serializable
data class FontEntry(
    val id: String,
    val displayName: String,
    val family: String?,
    val subfamily: String?,
    val extension: String,
    val fileName: String,
    val sizeBytes: Long,
    val glyphCount: Int?,
    val weightClass: Int?,
    val isVariable: Boolean,
    val importedAt: Long,
    val originalFileName: String?,
) {
    val format: FontFormat get() = FontFormat.fromExtension(extension) ?: FontFormat.TRUETYPE

    /** Résumé compact affiché sous le nom dans la bibliothèque. */
    val summary: String
        get() = buildList {
            add(format.label)
            glyphCount?.let { add("$it glyphes") }
            weightClass?.let { add("graisse $it") }
            if (isVariable) add("variable")
            add(formatSize(sizeBytes))
        }.joinToString(" · ")

    /** Nom de fichier proposé à l'export. */
    val exportFileName: String
        get() = displayName.replace(Regex("[^\\p{L}\\p{N} ._-]"), "").trim().ifEmpty { id } + ".$extension"

    companion object {
        fun formatSize(bytes: Long): String = when {
            bytes >= 1024 * 1024 -> String.format(Locale.FRANCE, "%.1f Mo", bytes / (1024.0 * 1024.0))
            bytes >= 1024 -> String.format(Locale.FRANCE, "%d Ko", bytes / 1024)
            else -> "$bytes o"
        }
    }
}

@Serializable
data class FontIndex(
    val version: Int = 1,
    val fonts: List<FontEntry> = emptyList(),
)
