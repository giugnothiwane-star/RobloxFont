package com.rfc.fontchanger.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object RfcColors {
    val Background = Color(0xFF0B0D12)
    val Surface = Color(0xFF12151C)
    val SurfaceHigh = Color(0xFF1A1E27)
    val Outline = Color(0xFF2A303C)
    val Primary = Color(0xFF7C9CFF)
    val Secondary = Color(0xFF5EEAD4)
    val TextPrimary = Color(0xFFE6E8EE)
    val TextSecondary = Color(0xFF9AA3B2)
    val Success = Color(0xFF4ADE80)
    val Warning = Color(0xFFFBBF24)
    val Danger = Color(0xFFFF6B6B)
    val Info = Color(0xFF60A5FA)
}

private val Scheme = darkColorScheme(
    primary = RfcColors.Primary,
    onPrimary = Color(0xFF0B1020),
    primaryContainer = Color(0xFF1E2A55),
    onPrimaryContainer = RfcColors.TextPrimary,
    secondary = RfcColors.Secondary,
    onSecondary = Color(0xFF04201C),
    background = RfcColors.Background,
    onBackground = RfcColors.TextPrimary,
    surface = RfcColors.Surface,
    onSurface = RfcColors.TextPrimary,
    surfaceVariant = RfcColors.SurfaceHigh,
    onSurfaceVariant = RfcColors.TextSecondary,
    surfaceContainer = RfcColors.Surface,
    surfaceContainerHigh = RfcColors.SurfaceHigh,
    surfaceContainerLow = RfcColors.Surface,
    outline = RfcColors.Outline,
    outlineVariant = RfcColors.Outline,
    error = RfcColors.Danger,
)

private val AppTypography = Typography(
    headlineSmall = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.4.sp),
)

@Composable
fun RfcTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppTypography, content = content)
}
