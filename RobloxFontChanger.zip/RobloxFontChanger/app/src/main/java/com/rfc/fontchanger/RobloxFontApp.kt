package com.rfc.fontchanger

import android.app.Application
import android.content.Context
import com.rfc.fontchanger.data.FontRepository
import com.rfc.fontchanger.data.PreferencesRepository
import com.rfc.fontchanger.system.CompatibilityAnalyzer
import com.rfc.fontchanger.system.EnvironmentInspector
import com.rfc.fontchanger.system.RobloxFontScanner

class RobloxFontApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/** Conteneur de dépendances manuel : évite Hilt/Dagger pour un graphe aussi réduit. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val fontRepository = FontRepository(appContext)
    val preferencesRepository = PreferencesRepository(appContext)
    val environmentInspector = EnvironmentInspector(appContext)
    val robloxFontScanner = RobloxFontScanner(appContext)
    val compatibilityAnalyzer = CompatibilityAnalyzer(environmentInspector, robloxFontScanner)
}
