package com.rfc.fontchanger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.rfc.fontchanger.ui.MainRoute
import com.rfc.fontchanger.ui.theme.RfcTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            RfcTheme {
                MainRoute()
            }
        }
    }
}
