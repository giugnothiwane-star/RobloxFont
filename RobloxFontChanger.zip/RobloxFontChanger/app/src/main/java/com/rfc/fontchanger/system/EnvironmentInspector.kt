package com.rfc.fontchanger.system

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.Immutable
import androidx.core.content.pm.PackageInfoCompat

@Immutable
data class DeviceInfo(
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val oneUiVersion: String?,
    val securityPatch: String,
) {
    val androidLabel: String get() = "Android $androidRelease (API $sdkInt)"
}

enum class InstallerSource(val label: String, val isOfficial: Boolean) {
    PLAY_STORE("Google Play", true),
    GALAXY_STORE("Galaxy Store", true),
    AMAZON("Amazon Appstore", true),
    SIDELOADED("Installation manuelle (APK)", false),
    UNKNOWN("Source inconnue", false),
}

@Immutable
data class RobloxInfo(
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val installer: InstallerSource,
    val installerPackage: String?,
    val sourceDir: String?,
    val splitSourceDirs: List<String>,
    val dataDir: String?,
    val lastUpdateTime: Long,
) {
    val apkPaths: List<String> get() = listOfNotNull(sourceDir) + splitSourceDirs
}

class EnvironmentInspector(context: Context) {

    private val appContext = context.applicationContext
    private val pm: PackageManager = appContext.packageManager

    fun deviceInfo(): DeviceInfo = DeviceInfo(
        manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
        model = Build.MODEL,
        androidRelease = Build.VERSION.RELEASE,
        sdkInt = Build.VERSION.SDK_INT,
        oneUiVersion = readOneUiVersion(),
        securityPatch = Build.VERSION.SECURITY_PATCH,
    )

    /** Null si Roblox n'est installé sous aucun de ses identifiants connus. */
    fun robloxInfo(): RobloxInfo? {
        for (pkg in ROBLOX_PACKAGES) {
            val info = packageInfo(pkg) ?: continue
            val app = info.applicationInfo
            val installerPkg = installerPackage(pkg)
            return RobloxInfo(
                packageName = pkg,
                versionName = info.versionName ?: "inconnue",
                versionCode = PackageInfoCompat.getLongVersionCode(info),
                installer = classifyInstaller(installerPkg),
                installerPackage = installerPkg,
                sourceDir = app?.sourceDir,
                splitSourceDirs = app?.splitSourceDirs?.toList().orEmpty(),
                dataDir = app?.dataDir,
                lastUpdateTime = info.lastUpdateTime,
            )
        }
        return null
    }

    private fun packageInfo(pkg: String): PackageInfo? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(pkg, 0)
        }
    } catch (_: PackageManager.NameNotFoundException) {
        null
    }

    private fun installerPackage(pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pm.getInstallSourceInfo(pkg).installingPackageName
        } else {
            @Suppress("DEPRECATION")
            pm.getInstallerPackageName(pkg)
        }
    } catch (_: PackageManager.NameNotFoundException) {
        null
    } catch (_: IllegalArgumentException) {
        null
    } catch (_: SecurityException) {
        null
    }

    private fun classifyInstaller(installer: String?): InstallerSource = when (installer) {
        "com.android.vending" -> InstallerSource.PLAY_STORE
        "com.sec.android.app.samsungapps" -> InstallerSource.GALAXY_STORE
        "com.amazon.venezia" -> InstallerSource.AMAZON
        null -> InstallerSource.UNKNOWN
        // Tout autre installeur (packageinstaller système, navigateur, magasin tiers) = APK hors store officiel.
        else -> InstallerSource.SIDELOADED
    }

    /**
     * One UI expose sa version via le champ propriétaire Build.VERSION.SEM_PLATFORM_INT
     * (ex. 150100 → 6.1). Absent hors Samsung : on retourne null sans erreur.
     */
    private fun readOneUiVersion(): String? {
        if (!Build.MANUFACTURER.equals("samsung", ignoreCase = true)) return null
        return try {
            val value = Build.VERSION::class.java.getDeclaredField("SEM_PLATFORM_INT").getInt(null)
            if (value < 90_000) return null
            val major = (value - 90_000) / 10_000
            val minor = (value % 10_000) / 100
            "$major.$minor"
        } catch (_: ReflectiveOperationException) {
            null
        } catch (_: SecurityException) {
            null
        }
    }

    companion object {
        val ROBLOX_PACKAGES = listOf("com.roblox.client", "com.roblox.client.vnggames")
    }
}
