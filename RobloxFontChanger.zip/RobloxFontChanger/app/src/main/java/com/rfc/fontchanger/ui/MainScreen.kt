package com.rfc.fontchanger.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rfc.fontchanger.data.FontEntry
import com.rfc.fontchanger.system.EnvironmentInspector
import com.rfc.fontchanger.system.SystemIntents
import com.rfc.fontchanger.ui.components.EnvironmentCard
import com.rfc.fontchanger.ui.components.FontRow
import com.rfc.fontchanger.ui.components.PreviewCard
import com.rfc.fontchanger.ui.components.ReportSheet
import com.rfc.fontchanger.ui.components.rememberFontFamily
import com.rfc.fontchanger.ui.theme.RfcColors

/** Types MIME sous lesquels les fournisseurs de fichiers exposent couramment TTF/OTF. */
private val FONT_MIME_TYPES = arrayOf(
    "font/ttf", "font/otf", "font/sfnt",
    "application/x-font-ttf", "application/x-font-otf",
    "application/x-font-truetype", "application/x-font-opentype",
    "application/font-sfnt", "application/vnd.ms-opentype",
    // Beaucoup de gestionnaires de fichiers (dont My Files) déclarent les polices ainsi.
    "application/octet-stream",
)

/** CREATE_DOCUMENT avec type MIME dynamique (TTF ou OTF selon la police exportée). */
private class CreateFontDocument : ActivityResultContract<Pair<String, String>, Uri?>() {
    override fun createIntent(context: Context, input: Pair<String, String>): Intent =
        Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(input.second)
            .putExtra(Intent.EXTRA_TITLE, input.first)

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        intent?.data?.takeIf { resultCode == Activity.RESULT_OK }
}

@Composable
fun MainRoute(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(vm) {
        vm.messages.collect { snackbarHostState.showSnackbar(it) }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(vm::importFont)
    }

    // Survit à la recréation d'activité pendant que le sélecteur système est ouvert.
    var pendingExportId by rememberSaveable { mutableStateOf<String?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(CreateFontDocument()) { uri ->
        val entry = pendingExportId?.let(vm::findFont)
        pendingExportId = null
        when {
            uri == null -> Unit
            entry == null -> vm.notify("La police à exporter n'existe plus.")
            else -> vm.export(entry, uri)
        }
    }

    val actions = MainActions(
        onImport = {
            try {
                importLauncher.launch(FONT_MIME_TYPES)
            } catch (_: android.content.ActivityNotFoundException) {
                vm.notify("Aucun sélecteur de fichiers disponible sur cet appareil.")
            }
        },
        onApply = vm::onApplyRequested,
        onRestore = vm::onRestoreRequested,
        onRefresh = vm::refreshEnvironment,
        onSelect = vm::selectFont,
        onExport = { entry ->
            pendingExportId = entry.id
            try {
                exportLauncher.launch(entry.exportFileName to entry.format.mimeType)
            } catch (_: android.content.ActivityNotFoundException) {
                pendingExportId = null
                vm.notify("Aucune application ne permet d'enregistrer un fichier.")
            }
        },
        onShare = { entry ->
            vm.shareUriFor(entry)?.let { uri ->
                if (!SystemIntents.shareFont(context, uri, entry.format.mimeType, entry.displayName)) {
                    vm.notify("Aucune application de partage disponible.")
                }
            }
        },
        onDelete = vm::requestDelete,
    )

    MainScreen(state = state, vm = vm, actions = actions, snackbarHostState = snackbarHostState)

    state.report?.takeIf { state.showReport }?.let { report ->
        ReportSheet(report = report, onDismiss = vm::dismissReport)
    }

    if (state.showRestoreDialog) {
        RestoreDialog(
            robloxPackage = state.roblox?.packageName,
            onOpenDetails = { pkg ->
                if (!SystemIntents.openAppDetails(context, pkg)) vm.notify("Impossible d'ouvrir les paramètres de l'application.")
            },
            onOpenStore = { pkg ->
                if (!SystemIntents.openStorePage(context, pkg)) vm.notify("Aucun store disponible.")
            },
            onDismiss = vm::dismissRestore,
        )
    }

    state.pendingDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = vm::cancelDelete,
            title = { Text("Supprimer la police ?") },
            text = { Text("« ${entry.displayName} » sera retirée de la bibliothèque et son fichier effacé de l'application.") },
            confirmButton = {
                TextButton(onClick = vm::confirmDelete) { Text("Supprimer", color = RfcColors.Danger) }
            },
            dismissButton = { TextButton(onClick = vm::cancelDelete) { Text("Annuler") } },
        )
    }
}

private data class MainActions(
    val onImport: () -> Unit,
    val onApply: () -> Unit,
    val onRestore: () -> Unit,
    val onRefresh: () -> Unit,
    val onSelect: (FontEntry) -> Unit,
    val onExport: (FontEntry) -> Unit,
    val onShare: (FontEntry) -> Unit,
    val onDelete: (FontEntry) -> Unit,
)

@Composable
private fun MainScreen(
    state: MainUiState,
    vm: MainViewModel,
    actions: MainActions,
    snackbarHostState: SnackbarHostState,
) {
    val activeFamily = rememberFontFamily(state.activeFont, vm::typefaceFor)
    val originalFamily = rememberFontFamily(state.originalTypeface)
    val entrance = remember { MutableTransitionState(false).apply { targetState = true } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding)) {
            AnimatedVisibility(visible = state.isImporting || state.isAnalyzing) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            LazyColumn(
                modifier = Modifier.fillMaxSize().imePadding(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item(key = "header") {
                    AnimatedVisibility(
                        visibleState = entrance,
                        enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { -it / 3 },
                    ) {
                        Column {
                            Text("Font Changer", style = MaterialTheme.typography.headlineSmall)
                            Text(
                                "Polices personnalisées · Roblox Android",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                item(key = "env") {
                    EnvironmentCard(device = state.device, roblox = state.roblox, onRefresh = actions.onRefresh)
                }

                item(key = "preview") {
                    PreviewCard(
                        activeName = state.activeFont?.displayName,
                        family = activeFamily,
                        originalFamily = originalFamily,
                        originalName = state.originalFont?.fileName,
                        text = state.previewText,
                        sizeSp = state.previewSizeSp,
                        scene = state.scene,
                        compare = state.compareWithOriginal,
                        onTextChange = vm::onPreviewTextChange,
                        onSizeChange = vm::onPreviewSizeChange,
                        onSizeChangeFinished = vm::onPreviewSizeChangeFinished,
                        onSceneChange = vm::onSceneChange,
                        onCompareChange = vm::onCompareToggle,
                    )
                }

                item(key = "actions") {
                    ActionPanel(
                        isImporting = state.isImporting,
                        isAnalyzing = state.isAnalyzing,
                        onImport = actions.onImport,
                        onApply = actions.onApply,
                        onRestore = actions.onRestore,
                    )
                }

                item(key = "library_header") {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                        Text("Bibliothèque", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        Text(
                            "${state.fonts.size} police${if (state.fonts.size > 1) "s" else ""}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                if (state.libraryLoaded && state.fonts.isEmpty()) {
                    item(key = "empty") { EmptyLibrary(onImport = actions.onImport) }
                }

                items(state.fonts, key = { it.id }) { entry ->
                    FontRow(
                        entry = entry,
                        selected = entry.id == state.activeFont?.id,
                        loader = vm::typefaceFor,
                        onSelect = { actions.onSelect(entry) },
                        onExport = { actions.onExport(entry) },
                        onShare = { actions.onShare(entry) },
                        onDelete = { actions.onDelete(entry) },
                        modifier = Modifier.animateItem(),
                    )
                }

                item(key = "footer") { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun ActionPanel(
    isImporting: Boolean,
    isAnalyzing: Boolean,
    onImport: () -> Unit,
    onApply: () -> Unit,
    onRestore: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onImport, enabled = !isImporting, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            if (isImporting) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            } else {
                Icon(Icons.Default.Add, contentDescription = null)
            }
            Spacer(Modifier.width(8.dp))
            Text("Importer une police (.ttf / .otf)")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = onApply, enabled = !isAnalyzing, modifier = Modifier.weight(1f).height(48.dp)) {
                if (isAnalyzing) {
                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(6.dp))
                Text("Appliquer à Roblox")
            }
            OutlinedButton(onClick = onRestore, modifier = Modifier.weight(1f).height(48.dp)) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Restaurer l'origine")
            }
        }
        Text(
            "« Appliquer » exécute une analyse réelle de faisabilité sur votre appareil. " +
                "Rien n'est modifié lorsque Android l'interdit.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun EmptyLibrary(onImport: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Aucune police", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "Importez un fichier .ttf ou .otf depuis vos téléchargements, Google Drive ou My Files.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            TextButton(onClick = onImport) { Text("Importer maintenant") }
        }
    }
}

@Composable
private fun RestoreDialog(
    robloxPackage: String?,
    onOpenDetails: (String) -> Unit,
    onOpenStore: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val pkg = robloxPackage ?: EnvironmentInspector.ROBLOX_PACKAGES.first()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Police d'origine") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("L'aperçu utilise de nouveau la police d'origine de Roblox.")
                Text(
                    "Cette application n'a jamais modifié Roblox : ses polices d'origine sont intactes. " +
                        "Si un autre outil ou un APK modifié a altéré Roblox, la seule restauration fiable est " +
                        "de le désinstaller puis de le réinstaller depuis le store officiel.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (robloxPackage != null) {
                        TextButton(onClick = { onOpenDetails(pkg) }) { Text("Infos de l'app") }
                    }
                    TextButton(onClick = { onOpenStore(pkg) }) { Text("Ouvrir le store") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } },
    )
}
