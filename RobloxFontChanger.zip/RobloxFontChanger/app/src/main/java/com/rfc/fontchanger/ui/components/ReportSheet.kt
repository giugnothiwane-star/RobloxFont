package com.rfc.fontchanger.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rfc.fontchanger.data.FontEntry
import com.rfc.fontchanger.system.CheckResult
import com.rfc.fontchanger.system.CheckStatus
import com.rfc.fontchanger.system.CompatibilityReport
import com.rfc.fontchanger.ui.theme.RfcColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportSheet(report: CompatibilityReport, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showAllFonts by rememberSaveable { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Appliquer à Roblox — analyse", style = MaterialTheme.typography.headlineSmall)

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = (if (report.canApply) RfcColors.Success else RfcColors.Danger).copy(alpha = 0.14f)
                ),
            ) {
                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(
                        if (report.canApply) Icons.Default.CheckCircle else Icons.Default.Lock,
                        contentDescription = null,
                        tint = if (report.canApply) RfcColors.Success else RfcColors.Danger,
                    )
                    Text(report.verdict, style = MaterialTheme.typography.bodyMedium)
                }
            }

            Text("Vérifications effectuées sur l'appareil", style = MaterialTheme.typography.titleMedium)
            report.checks.forEach { CheckRow(it) }

            if (report.bundledFonts.isNotEmpty()) {
                HorizontalDivider()
                Column(Modifier.animateContentSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Polices trouvées dans Roblox (${report.bundledFonts.size})", style = MaterialTheme.typography.titleMedium)
                    val visible = if (showAllFonts) report.bundledFonts else report.bundledFonts.take(FONT_PREVIEW_COUNT)
                    visible.forEach { f ->
                        Text(
                            "${f.fileName} · ${FontEntry.formatSize(f.sizeBytes)} · ${f.apkName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (report.bundledFonts.size > FONT_PREVIEW_COUNT) {
                        TextButton(onClick = { showAllFonts = !showAllFonts }) {
                            Text(if (showAllFonts) "Réduire" else "Voir les ${report.bundledFonts.size - FONT_PREVIEW_COUNT} autres")
                        }
                    }
                }
            }

            HorizontalDivider()
            Text("Ce que l'application peut réellement faire", style = MaterialTheme.typography.titleMedium)
            report.alternatives.forEach { alt ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("•", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(alt, style = MaterialTheme.typography.bodyMedium)
                }
            }

            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Compris") }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun CheckRow(check: CheckResult) {
    val (icon, tint) = check.status.visual()
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(icon, contentDescription = check.status.name, tint = tint, modifier = Modifier.size(22.dp))
        Column(Modifier.weight(1f)) {
            Text(check.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(check.detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun CheckStatus.visual(): Pair<ImageVector, androidx.compose.ui.graphics.Color> = when (this) {
    CheckStatus.OK -> Icons.Default.CheckCircle to RfcColors.Success
    CheckStatus.INFO -> Icons.Default.Info to RfcColors.Info
    CheckStatus.WARNING -> Icons.Default.Warning to RfcColors.Warning
    CheckStatus.BLOCKED -> Icons.Default.Lock to RfcColors.Danger
}

private const val FONT_PREVIEW_COUNT = 8
