package com.rfc.fontchanger.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_prefs")

enum class PreviewScene(val label: String) { CHAT("Chat"), MENU("Menus"), NAMETAG("Pseudos") }

data class UserPreferences(
    val activeFontId: String? = null,
    val previewText: String = DEFAULT_PREVIEW_TEXT,
    val previewSizeSp: Float = DEFAULT_PREVIEW_SIZE,
    val compareWithOriginal: Boolean = true,
    val scene: PreviewScene = PreviewScene.CHAT,
) {
    companion object {
        const val DEFAULT_PREVIEW_TEXT = "gg ez, on refait une partie ?"
        const val DEFAULT_PREVIEW_SIZE = 18f
        val SIZE_RANGE = 10f..40f
        const val MAX_PREVIEW_LENGTH = 200
    }
}

class PreferencesRepository(context: Context) {

    private val store = context.applicationContext.dataStore

    private object Keys {
        val ACTIVE_FONT = stringPreferencesKey("active_font_id")
        val PREVIEW_TEXT = stringPreferencesKey("preview_text")
        val PREVIEW_SIZE = floatPreferencesKey("preview_size_sp")
        val COMPARE = booleanPreferencesKey("compare_with_original")
        val SCENE = stringPreferencesKey("preview_scene")
    }

    val preferences: Flow<UserPreferences> = store.data
        // Un fichier de préférences corrompu ne doit jamais bloquer l'application.
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            UserPreferences(
                activeFontId = p[Keys.ACTIVE_FONT],
                previewText = p[Keys.PREVIEW_TEXT] ?: UserPreferences.DEFAULT_PREVIEW_TEXT,
                previewSizeSp = (p[Keys.PREVIEW_SIZE] ?: UserPreferences.DEFAULT_PREVIEW_SIZE)
                    .coerceIn(UserPreferences.SIZE_RANGE),
                compareWithOriginal = p[Keys.COMPARE] ?: true,
                scene = p[Keys.SCENE]?.let { name -> PreviewScene.entries.firstOrNull { it.name == name } }
                    ?: PreviewScene.CHAT,
            )
        }
        .distinctUntilChanged()

    suspend fun setActiveFont(id: String?) = store.edit { p ->
        if (id == null) p.remove(Keys.ACTIVE_FONT) else p[Keys.ACTIVE_FONT] = id
    }

    suspend fun setPreviewText(text: String) = store.edit {
        it[Keys.PREVIEW_TEXT] = text.take(UserPreferences.MAX_PREVIEW_LENGTH)
    }

    suspend fun setPreviewSize(sizeSp: Float) = store.edit {
        it[Keys.PREVIEW_SIZE] = sizeSp.coerceIn(UserPreferences.SIZE_RANGE)
    }

    suspend fun setCompareWithOriginal(enabled: Boolean) = store.edit { it[Keys.COMPARE] = enabled }

    suspend fun setScene(scene: PreviewScene) = store.edit { it[Keys.SCENE] = scene.name }
}
