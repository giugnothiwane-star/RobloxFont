package com.rfc.fontchanger.data

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import android.system.ErrnoException
import android.system.OsConstants
import android.util.AtomicFile
import android.util.LruCache
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/**
 * Bibliothèque de polices stockée dans le stockage interne de l'application.
 * Les fichiers sont nommés par empreinte SHA-256 : déduplication gratuite et
 * aucune collision possible entre deux polices homonymes.
 */
class FontRepository(
    context: Context,
    private val io: CoroutineDispatcher = Dispatchers.IO,
) {
    private val appContext = context.applicationContext
    private val fontsDir = File(appContext.filesDir, FONTS_DIR)
    private val indexFile = AtomicFile(File(fontsDir, INDEX_FILE))
    private val mutex = Mutex()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private val _fonts = MutableStateFlow<List<FontEntry>>(emptyList())
    val fonts: StateFlow<List<FontEntry>> = _fonts.asStateFlow()

    private val typefaceCache = LruCache<String, Typeface>(TYPEFACE_CACHE_SIZE)

    suspend fun load() = withContext(io) {
        mutex.withLock {
            ensureDir()
            val loaded = readIndexOrRebuild()
            // Purge des entrées dont le fichier a disparu (nettoyage système, restauration partielle).
            val existing = loaded.filter { File(fontsDir, it.fileName).isFile }
            if (existing.size != loaded.size) persist(existing)
            _fonts.value = existing.sortedByDescending { it.importedAt }
        }
    }

    suspend fun import(uri: Uri): FontEntry = withContext(io) {
        ensureDir()
        val resolver = appContext.contentResolver
        val (originalName, declaredSize) = queryNameAndSize(uri)
        if (declaredSize != null && declaredSize > MAX_FONT_BYTES) throw AppError.FileTooLarge(MAX_FONT_BYTES)

        val temp = File.createTempFile("import_", ".tmp", appContext.cacheDir)
        try {
            val digest = MessageDigest.getInstance("SHA-256")
            val copied = try {
                resolver.openInputStream(uri)?.use { input -> copyCapped(input, temp, digest) }
                    ?: throw AppError.UnreadableSource()
            } catch (e: FileNotFoundException) {
                throw AppError.UnreadableSource(e)
            } catch (e: SecurityException) {
                throw AppError.UnreadableSource(e)
            }
            if (copied == 0L) throw AppError.EmptyFile()

            val metadata = FontParser.parse(temp)
            val typeface = Typeface.Builder(temp).build() ?: throw AppError.TypefaceRejected()

            val id = digest.digest().joinToString("") { "%02x".format(it) }.take(ID_LENGTH)
            val entry = mutex.withLock {
                _fonts.value.firstOrNull { it.id == id }?.let { throw AppError.AlreadyImported(it.displayName) }

                val fileName = "$id.${metadata.format.extension}"
                val dest = File(fontsDir, fileName)
                moveFile(temp, dest)

                val newEntry = FontEntry(
                    id = id,
                    displayName = metadata.fullName
                        ?: listOfNotNull(metadata.family, metadata.subfamily).joinToString(" ").ifEmpty { null }
                        ?: originalName?.substringBeforeLast('.')
                        ?: "Police $id",
                    family = metadata.family,
                    subfamily = metadata.subfamily,
                    extension = metadata.format.extension,
                    fileName = fileName,
                    sizeBytes = copied,
                    glyphCount = metadata.glyphCount,
                    weightClass = metadata.weightClass,
                    isVariable = metadata.isVariable,
                    importedAt = System.currentTimeMillis(),
                    originalFileName = originalName,
                )
                val updated = listOf(newEntry) + _fonts.value
                persist(updated)
                _fonts.value = updated
                newEntry
            }
            typefaceCache.put(entry.id, typeface)
            entry
        } catch (e: IOException) {
            throw if (e.isNoSpace()) AppError.StorageFull(e) else AppError.UnreadableSource(e)
        } finally {
            if (temp.exists()) temp.delete()
        }
    }

    suspend fun delete(id: String) = withContext(io) {
        mutex.withLock {
            val target = _fonts.value.firstOrNull { it.id == id } ?: return@withLock
            File(fontsDir, target.fileName).delete()
            val updated = _fonts.value - target
            persist(updated)
            _fonts.value = updated
            typefaceCache.remove(id)
        }
    }

    suspend fun exportTo(entry: FontEntry, target: Uri) = withContext(io) {
        val source = fileFor(entry)
        if (!source.isFile) throw AppError.FontNotFound()
        try {
            val out: OutputStream = appContext.contentResolver.openOutputStream(target, "wt")
                ?: throw AppError.ExportFailed()
            out.use { stream -> source.inputStream().use { it.copyTo(stream, BUFFER_SIZE) } }
        } catch (e: AppError) {
            throw e
        } catch (e: IOException) {
            throw if (e.isNoSpace()) AppError.StorageFull(e) else AppError.ExportFailed(e)
        } catch (e: SecurityException) {
            throw AppError.ExportFailed(e)
        }
    }

    suspend fun typefaceFor(entry: FontEntry): Typeface? = withContext(io) {
        typefaceCache.get(entry.id) ?: run {
            val file = fileFor(entry)
            if (!file.isFile) return@run null
            Typeface.Builder(file).build()?.also { typefaceCache.put(entry.id, it) }
        }
    }

    fun fileFor(entry: FontEntry): File = File(fontsDir, entry.fileName)

    fun shareUri(entry: FontEntry): Uri {
        val file = fileFor(entry)
        if (!file.isFile) throw AppError.FontNotFound()
        return FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file)
    }

    // --- Interne ---------------------------------------------------------------------------

    private fun ensureDir() {
        if (!fontsDir.isDirectory && !fontsDir.mkdirs()) throw AppError.StorageFull()
    }

    private fun readIndexOrRebuild(): List<FontEntry> {
        if (!indexFile.baseFile.exists()) return rebuildFromDisk()
        return try {
            val text = indexFile.readFully().toString(Charsets.UTF_8)
            json.decodeFromString(FontIndex.serializer(), text).fonts
        } catch (e: SerializationException) {
            rebuildFromDisk()
        } catch (e: IllegalArgumentException) {
            rebuildFromDisk()
        } catch (e: IOException) {
            rebuildFromDisk()
        }
    }

    /** Reconstruit l'index à partir des fichiers présents si le JSON est perdu ou corrompu. */
    private fun rebuildFromDisk(): List<FontEntry> {
        val files = fontsDir.listFiles { f -> f.isFile && FontFormat.fromExtension(f.extension) != null }.orEmpty()
        val rebuilt = files.mapNotNull { file ->
            runCatching {
                val meta = FontParser.parse(file)
                FontEntry(
                    id = file.nameWithoutExtension,
                    displayName = meta.fullName ?: meta.family ?: file.nameWithoutExtension,
                    family = meta.family,
                    subfamily = meta.subfamily,
                    extension = meta.format.extension,
                    fileName = file.name,
                    sizeBytes = file.length(),
                    glyphCount = meta.glyphCount,
                    weightClass = meta.weightClass,
                    isVariable = meta.isVariable,
                    importedAt = file.lastModified(),
                    originalFileName = null,
                )
            }.getOrNull()
        }
        if (rebuilt.isNotEmpty() || indexFile.baseFile.exists()) persist(rebuilt)
        return rebuilt
    }

    private fun persist(entries: List<FontEntry>) {
        val stream = indexFile.startWrite()
        try {
            stream.write(json.encodeToString(FontIndex.serializer(), FontIndex(fonts = entries)).toByteArray(Charsets.UTF_8))
            indexFile.finishWrite(stream)
        } catch (e: IOException) {
            indexFile.failWrite(stream)
            throw if (e.isNoSpace()) AppError.StorageFull(e) else e
        }
    }

    private fun queryNameAndSize(uri: Uri): Pair<String?, Long?> = try {
        appContext.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
        )?.use { c ->
            if (!c.moveToFirst()) return@use null to null
            val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
            val name = if (nameIdx >= 0 && !c.isNull(nameIdx)) c.getString(nameIdx) else null
            val size = if (sizeIdx >= 0 && !c.isNull(sizeIdx)) c.getLong(sizeIdx) else null
            name to size
        } ?: (null to null)
    } catch (e: SecurityException) {
        throw AppError.UnreadableSource(e)
    } catch (e: IllegalArgumentException) {
        null to null
    }

    /** Copie avec plafond : la taille déclarée par le fournisseur n'est pas fiable. */
    private fun copyCapped(input: InputStream, dest: File, digest: MessageDigest): Long {
        var total = 0L
        val buffer = ByteArray(BUFFER_SIZE)
        dest.outputStream().use { out ->
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > MAX_FONT_BYTES) throw AppError.FileTooLarge(MAX_FONT_BYTES)
                digest.update(buffer, 0, read)
                out.write(buffer, 0, read)
            }
            out.fd.sync()
        }
        return total
    }

    private fun moveFile(source: File, dest: File) {
        if (source.renameTo(dest)) return
        // Repli si cache et fichiers sont sur des volumes distincts (cas rare sur certains OEM).
        source.inputStream().use { input -> dest.outputStream().use { input.copyTo(it, BUFFER_SIZE) } }
        source.delete()
    }

    private fun IOException.isNoSpace(): Boolean =
        (cause as? ErrnoException)?.errno == OsConstants.ENOSPC || message?.contains("ENOSPC") == true

    companion object {
        const val MAX_FONT_BYTES = 30L * 1024 * 1024
        private const val FONTS_DIR = "fonts"
        private const val INDEX_FILE = "index.json"
        private const val ID_LENGTH = 16
        private const val BUFFER_SIZE = 64 * 1024
        private const val TYPEFACE_CACHE_SIZE = 24
    }
}
