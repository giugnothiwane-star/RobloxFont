# kotlinx.serialization : conserve les serializers générés des modèles persistés.
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers @kotlinx.serialization.Serializable class com.rfc.fontchanger.** {
    *** Companion;
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.rfc.fontchanger.**$$serializer { *; }
