# RBX Font Changer (Android)

Application Kotlin / Jetpack Compose : bibliothèque de polices TTF/OTF, aperçu instantané dans des maquettes Roblox (chat, menus, pseudos), comparaison avec la police d'origine extraite de votre installation Roblox, et analyse réelle de la faisabilité d'un remplacement.

## Verdict technique (Android 16, sans root)

**Remplacer les polices de Roblox depuis une application tierce est impossible sans root.** Le bouton « Appliquer à Roblox » ne simule donc aucun succès : il exécute des vérifications réelles sur l'appareil et affiche un rapport.

| Emplacement | Contenu | Accès d'une app tierce |
|---|---|---|
| `/data/app/~~…/com.roblox.client-…/base.apk` (+ splits) | Polices embarquées dans l'APK | **Lecture seule.** Fichier signé : toute modification casse la signature, Android refuse l'installation/mise à jour. |
| `/data/user/0/com.roblox.client` | Données privées | **Aucun.** Isolation par UID Linux + SELinux. |
| `/sdcard/Android/data/com.roblox.client` | Cache externe | **Bloqué** par le scoped storage (Android 11+). Depuis Android 13, le sélecteur SAF refuse même ce dossier. Et Roblox n'y lit aucune police. |

Différence avec Bloxstrap : sur Windows, le client Roblox est un dossier ordinaire (`Versions/…/content/fonts`) que Bloxstrap remplace avant le lancement. Sur Android, ce contenu est dans un APK signé, et Roblox n'expose aucun dossier, réglage ou API de surcharge de police.

Ce qui n'est **pas** fait, volontairement : APK Roblox modifié/re-signé, demande d'identifiants, contournement de protections, Shizuku/ADB (même avec l'accès shell, ni l'APK ni le bac à sable de Roblox ne sont modifiables, et aucun dossier de surcharge n'est lu par Roblox).

Changer la police système Samsung n'aide pas non plus : Roblox dessine son interface avec ses propres polices embarquées.

## Ce que l'application fait réellement

- Import SAF de `.ttf` / `.otf`, sans aucune permission de stockage.
- Validation structurelle (parseur SFNT maison) : rejette WOFF/WOFF2/TTC avec un message dédié, détecte les tables manquantes, puis valide via le moteur `Typeface`.
- Bibliothèque persistante (stockage interne, déduplication SHA-256, index JSON écrit atomiquement, reconstruction automatique si corrompu).
- Aperçu instantané : chat, menus, pseudos ; texte et taille modifiables.
- Comparaison avec la police **d'origine lue dans l'APK de Roblox** (lecture seule, copie dans le cache de l'app).
- Détection : modèle, Android/API, One UI, correctif de sécurité, version de Roblox, source d'installation (Play/Galaxy Store vs APK manuel).
- Export (SAF) et partage (FileProvider) — par exemple vers un PC équipé de Bloxstrap.
- Préférences sauvegardées (DataStore) : police active, texte, taille, scène, comparaison.

## Produire l'APK sans ordinateur (GitHub Actions)

1. Créez un dépôt GitHub et envoyez-y le contenu de ce dossier (le workflow est dans `.github/workflows/build-apk.yml`).
2. Onglet **Actions** → « Build APK » → **Run workflow** (ou simple push sur `main`).
3. Une fois terminé (~5 min), ouvrez l'exécution → **Artifacts** → `RobloxFontChanger-debug` → téléchargez le zip, extrayez l'APK.
4. Sur le Samsung : autorisez l'installation depuis l'application utilisée (Mes fichiers / navigateur) puis installez.

L'APK debug est signé avec une clé de débogage : installable tel quel, mais une version signée différemment devra être désinstallée avant réinstallation.

## Avec Android Studio

Ouvrir le dossier → laisser Gradle synchroniser → `Build > Build App Bundle(s) / APK(s) > Build APK(s)`. Pour une release : `Build > Generate Signed App Bundle / APK` avec votre propre keystore.

Versions : AGP 8.9.1 · Gradle 8.11.1 · Kotlin 2.1.20 · Compose BOM 2025.04.00 · compileSdk/targetSdk 36 · minSdk 26 · JDK 17.

## Permissions

Aucune permission dangereuse. La visibilité sur Roblox passe par `<queries>` ciblé (pas de `QUERY_ALL_PACKAGES`), l'import/export par le Storage Access Framework (pas de `MANAGE_EXTERNAL_STORAGE`).
